# ESP Project Control Hub

A GitHub-ready starter pack for building a Power Apps and Power Automate project control system.

This repo gives you:

1. SharePoint List schemas for your project database
2. A PowerShell script to create the SharePoint Lists
3. Power Apps screen structure and Power Fx formulas
4. Power Automate flow templates and Copilot prompts
5. A React web preview so you can show the idea visually before rebuilding it in Power Apps

Important reality check:

Power Apps and Power Automate cannot normally be imported from plain GitHub files without packaging them as a Power Platform Solution using Microsoft tooling. This repo is designed as a build blueprint and source-control starter. The SharePoint script is directly usable. The Power Fx, flow templates and prompts are designed to be pasted/adapted inside Power Apps and Power Automate.

## System purpose

The hub is designed to give one place to manage:

Engineer updates  
Approval evidence  
Escalations  
ServiceNow tickets  
Finance and PO risks  
Customer update drafts  
Attendance evidence  
Weekly manager updates  

## Fastest build route

1. Create a SharePoint site called `Project Automation Hub`
2. Run `sharepoint/create-lists.ps1`
3. Build the Power App using `powerapps/APP-BLUEPRINT.md`
4. Create the flows using the files in `flows/prompts`
5. Use `web-preview` as a visual reference or clickable prototype

## Suggested Power Platform naming

App name:

```text
ESP Project Control Hub
```

SharePoint site:

```text
Project Automation Hub
```

Document library:

```text
Project Evidence Library
```

## Repo layout

```text
sharepoint/
  create-lists.ps1
  list-schemas.json

powerapps/
  APP-BLUEPRINT.md
  formulas.fx.yaml
  screens/

flows/
  prompts/
  templates/

web-preview/
  React TypeScript preview app

docs/
  SETUP_GUIDE.md
  ARCHITECTURE.md
```

## What to build first

Build in this order:

1. Approval Evidence Collector
2. Escalation Detector
3. Engineer Update Log
4. Customer Update Draft
5. PO Burn Tracker
6. Finance Variance Alert
7. ServiceNow Ticket Tracker
8. Attendance Evidence Log
9. Weekly Manager Update Builder
10. Full Project Dashboard

## Safety note

Do not put personal mediation, property, HR or legal evidence into your ESP work account. Keep personal legal evidence in your own personal Microsoft account only.
