# Web Preview

This is a React TypeScript visual prototype of the ESP Project Control Hub.

It is not the Power Apps version.

Use it to show the dashboard idea, test the layout, or share the concept through GitHub.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
