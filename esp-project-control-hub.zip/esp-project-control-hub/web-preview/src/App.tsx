import { AlertTriangle, BadgeCheck, CalendarClock, FileCheck2, Gauge, MailPlus, ShieldAlert, Truck } from "lucide-react";
import { approvalEvidence, engineerUpdates, escalations, financeRisks, poBurn } from "./data/sampleData";
import { Card } from "./components/Card";
import { StatusPill } from "./components/StatusPill";
import "./styles.css";

function currency(value: number) {
  return new Intl.NumberFormat("en-GB", {
    style: "currency",
    currency: "EUR"
  }).format(value);
}

export default function App() {
  const openEscalations = escalations.filter((item) => item.currentStatus !== "Closed");
  const approvalsAwaiting = approvalEvidence.filter((item) => item.approvalStatus === "Awaiting Customer Approval");
  const poAtRisk = poBurn.filter((item) => item.riskStatus === "At Risk" || item.amountUsed / item.poValue >= 0.8);
  const highFinanceRisks = financeRisks.filter((item) => item.riskLevel === "High" || item.riskLevel === "Critical");
  const customerDraftsNeeded = engineerUpdates.filter((item) => item.customerUpdateNeeded);

  return (
    <main className="app-shell">
      <header className="hero">
        <div>
          <p className="eyebrow">ESP Project Control Hub</p>
          <h1>One control panel for updates, approvals, risks and evidence.</h1>
          <p className="hero-copy">
            This is the GitHub preview version of the Power Apps build. Use it to visualise the dashboard before rebuilding it in Power Apps.
          </p>
        </div>
        <div className="hero-actions">
          <button>New engineer update</button>
          <button className="secondary">Log approval</button>
        </div>
      </header>

      <section className="metric-grid">
        <Card title="Open escalations" value={openEscalations.length} />
        <Card title="Approvals awaiting" value={approvalsAwaiting.length} />
        <Card title="POs at risk" value={poAtRisk.length} />
        <Card title="Finance risks" value={highFinanceRisks.length} />
        <Card title="Customer drafts needed" value={customerDraftsNeeded.length} />
        <Card title="Engineer updates today" value={engineerUpdates.length} />
      </section>

      <section className="two-column">
        <Card title="Priority board">
          <div className="priority-list">
            <div className="priority-item">
              <ShieldAlert />
              <div>
                <strong>Escalations</strong>
                <p>Track complaint, safety, customer and service failure risks.</p>
              </div>
              <StatusPill label={`${openEscalations.length} open`} />
            </div>
            <div className="priority-item">
              <FileCheck2 />
              <div>
                <strong>Approval evidence</strong>
                <p>Capture who approved what, when, and against which PO.</p>
              </div>
              <StatusPill label={`${approvalsAwaiting.length} awaiting`} />
            </div>
            <div className="priority-item">
              <Gauge />
              <div>
                <strong>PO burn</strong>
                <p>Flag any PO over 80 percent used or missing approval evidence.</p>
              </div>
              <StatusPill label={`${poAtRisk.length} at risk`} />
            </div>
            <div className="priority-item">
              <Truck />
              <div>
                <strong>Engineer updates</strong>
                <p>Log arrival, progress, blockers, photos and completion status.</p>
              </div>
              <StatusPill label={`${engineerUpdates.length} today`} />
            </div>
          </div>
        </Card>

        <Card title="Suggested actions">
          <div className="action-list">
            <button><MailPlus /> Generate customer update draft</button>
            <button><CalendarClock /> Log attendance evidence</button>
            <button><BadgeCheck /> Add approval evidence</button>
            <button><AlertTriangle /> Create escalation record</button>
          </div>
        </Card>
      </section>

      <section className="table-section">
        <Card title="Engineer updates">
          <table>
            <thead>
              <tr>
                <th>Project</th>
                <th>Site</th>
                <th>Engineer</th>
                <th>Status</th>
                <th>Next action</th>
              </tr>
            </thead>
            <tbody>
              {engineerUpdates.map((item) => (
                <tr key={item.id}>
                  <td>{item.project}</td>
                  <td>{item.siteName}</td>
                  <td>{item.engineer}</td>
                  <td><StatusPill label={item.completionStatus} /></td>
                  <td>{item.nextAction}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </section>

      <section className="table-section">
        <Card title="PO burn tracker">
          <table>
            <thead>
              <tr>
                <th>Customer</th>
                <th>PO</th>
                <th>Value</th>
                <th>Used</th>
                <th>Remaining</th>
                <th>Risk</th>
              </tr>
            </thead>
            <tbody>
              {poBurn.map((item) => {
                const remaining = item.poValue - item.amountUsed;
                return (
                  <tr key={item.id}>
                    <td>{item.customer}</td>
                    <td>{item.poNumber}</td>
                    <td>{currency(item.poValue)}</td>
                    <td>{currency(item.amountUsed)}</td>
                    <td>{currency(remaining)}</td>
                    <td><StatusPill label={item.riskStatus} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </section>
    </main>
  );
}
