interface StatusPillProps {
  label: string;
}

export function StatusPill({ label }: StatusPillProps) {
  const normalized = label.toLowerCase();
  const className =
    normalized.includes("critical") || normalized.includes("high") || normalized.includes("risk")
      ? "pill danger"
      : normalized.includes("awaiting") || normalized.includes("amber") || normalized.includes("needs")
        ? "pill warning"
        : "pill";

  return <span className={className}>{label}</span>;
}
