import type { ReactNode } from "react";

interface CardProps {
  title: string;
  value?: string | number;
  children?: ReactNode;
}

export function Card({ title, value, children }: CardProps) {
  return (
    <section className="card">
      <div className="card-title">{title}</div>
      {value !== undefined && <div className="card-value">{value}</div>}
      {children}
    </section>
  );
}
