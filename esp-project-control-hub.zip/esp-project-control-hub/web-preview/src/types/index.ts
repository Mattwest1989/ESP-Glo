export type ProjectName =
  | "Image Holders"
  | "Five Guys"
  | "Cleveron"
  | "Joe & The Juice"
  | "SITA iProov"
  | "Internal";

export type RiskLevel = "Low" | "Medium" | "High" | "Critical";

export type EngineerStatus =
  | "Not Started"
  | "Onsite"
  | "In Progress"
  | "Blocked"
  | "Complete"
  | "Needs Revisit";

export interface EngineerUpdate {
  id: string;
  updateDate: string;
  project: ProjectName;
  siteName: string;
  engineer: string;
  arrivalTime: string;
  completionStatus: EngineerStatus;
  workCompleted: string;
  blockers: string;
  photosTaken: boolean;
  nextAction: string;
  customerUpdateNeeded: boolean;
}

export interface ApprovalEvidence {
  id: string;
  approvalDate: string;
  project: ProjectName;
  customer: string;
  approverName: string;
  approvalWording: string;
  poNumber: string;
  invoiceValue: number;
  approvalStatus: "Approved" | "Awaiting Customer Approval" | "Rejected" | "Needs Evidence" | "Under Review";
}

export interface Escalation {
  id: string;
  dateRaised: string;
  project: ProjectName;
  customer: string;
  issue: string;
  riskLevel: RiskLevel;
  owner: string;
  currentStatus: "New" | "In Progress" | "Waiting" | "Escalated" | "Resolved" | "Closed";
  nextAction: string;
}

export interface PoBurn {
  id: string;
  customer: string;
  project: ProjectName;
  poNumber: string;
  poValue: number;
  amountUsed: number;
  approvalStatus: "Missing" | "Awaiting" | "Approved" | "Rejected" | "Not Required";
  riskStatus: "Green" | "Amber" | "Red" | "At Risk";
}

export interface FinanceRisk {
  id: string;
  project: ProjectName;
  projectValue: number;
  actualCost: number;
  forecastCostAtCompletion: number;
  forecastRevenue: number;
  riskLevel: RiskLevel;
  nextAction: string;
}
