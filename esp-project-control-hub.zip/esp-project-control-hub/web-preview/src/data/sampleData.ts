import type { ApprovalEvidence, EngineerUpdate, Escalation, FinanceRisk, PoBurn } from "../types";

export const engineerUpdates: EngineerUpdate[] = [
  {
    id: "eng-001",
    updateDate: new Date().toISOString(),
    project: "Five Guys",
    siteName: "Rosny 2",
    engineer: "Danish Malik",
    arrivalTime: "10:00",
    completionStatus: "In Progress",
    workCompleted: "Engineer onsite and completing readiness checks.",
    blockers: "Waiting for final site access confirmation.",
    photosTaken: true,
    nextAction: "Confirm whether install can proceed after works are complete.",
    customerUpdateNeeded: true
  },
  {
    id: "eng-002",
    updateDate: new Date().toISOString(),
    project: "Cleveron",
    siteName: "Bond Street",
    engineer: "Field Team",
    arrivalTime: "09:00",
    completionStatus: "Complete",
    workCompleted: "Robot unit installed and checked.",
    blockers: "None reported.",
    photosTaken: true,
    nextAction: "Send close-out update to customer.",
    customerUpdateNeeded: true
  }
];

export const approvalEvidence: ApprovalEvidence[] = [
  {
    id: "app-001",
    approvalDate: new Date().toISOString(),
    project: "Image Holders",
    customer: "imageHOLDERS",
    approverName: "Dean / Rick",
    approvalWording: "Agreed billable value pending evidence validation.",
    poNumber: "0000031418",
    invoiceValue: 18043.61,
    approvalStatus: "Needs Evidence"
  },
  {
    id: "app-002",
    approvalDate: new Date().toISOString(),
    project: "Five Guys",
    customer: "Five Guys France",
    approverName: "Customer Contact",
    approvalWording: "Survey dates to be rearranged once works complete.",
    poNumber: "TBC",
    invoiceValue: 0,
    approvalStatus: "Awaiting Customer Approval"
  }
];

export const escalations: Escalation[] = [
  {
    id: "esc-001",
    dateRaised: new Date().toISOString(),
    project: "Image Holders",
    customer: "Five Guys",
    issue: "Kiosk fixing issue requires evidence-backed close-out narrative.",
    riskLevel: "High",
    owner: "Matthew",
    currentStatus: "In Progress",
    nextAction: "Confirm evidence pack and senior stakeholder update."
  }
];

export const poBurn: PoBurn[] = [
  {
    id: "po-001",
    customer: "imageHOLDERS",
    project: "Image Holders",
    poNumber: "0000031418",
    poValue: 50487.51,
    amountUsed: 42100,
    approvalStatus: "Approved",
    riskStatus: "At Risk"
  },
  {
    id: "po-002",
    customer: "imageHOLDERS",
    project: "Image Holders",
    poNumber: "0000031624",
    poValue: 96240.5,
    amountUsed: 55000,
    approvalStatus: "Missing",
    riskStatus: "Amber"
  }
];

export const financeRisks: FinanceRisk[] = [
  {
    id: "fin-001",
    project: "Image Holders",
    projectValue: 96240.5,
    actualCost: 61000,
    forecastCostAtCompletion: 99000,
    forecastRevenue: 96240.5,
    riskLevel: "High",
    nextAction: "Validate billable scope and PO coverage before next finance review."
  }
];
