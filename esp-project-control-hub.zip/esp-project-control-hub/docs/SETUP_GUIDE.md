# Setup Guide

## Step 1: Create the SharePoint site

Create a SharePoint site called:

```text
Project Automation Hub
```

Create a document library called:

```text
Project Evidence Library
```

Suggested folders:

```text
Image Holders
Five Guys
Cleveron
Joe & The Juice
SITA iProov
Internal Attendance Evidence
Weekly Reports
Incoming Survey Photos
```

## Step 2: Create the SharePoint Lists

Run:

```powershell
cd sharepoint
.\create-lists.ps1 -SiteUrl "https://YOURTENANT.sharepoint.com/sites/ProjectAutomationHub"
```

You need the PnP.PowerShell module:

```powershell
Install-Module PnP.PowerShell -Scope CurrentUser
```

## Step 3: Build the Power App

Go to:

```text
make.powerapps.com
```

Create a canvas app called:

```text
ESP Project Control Hub
```

Connect it to the SharePoint Lists created by the script.

Use:

```text
powerapps/APP-BLUEPRINT.md
powerapps/formulas.fx.yaml
powerapps/screens/
```

## Step 4: Create the Power Automate flows

Use the prompts in:

```text
flows/prompts/
```

Create them in this order:

```text
approval-evidence-collector
escalation-detector
engineer-update-customer-draft
po-burn-alert
finance-variance-alert
attendance-evidence-log
weekly-manager-update
```

## Step 5: Optional React preview

The `web-preview` folder is a React TypeScript visual prototype.

Run:

```bash
cd web-preview
npm install
npm run dev
```

This does not replace Power Apps. It helps show the intended dashboard layout.
