# Architecture

## Simple architecture

```text
Power Apps
  Front-end control panel

SharePoint Lists
  Structured project database

SharePoint Document Library
  Evidence storage

Power Automate
  Workflow engine

Outlook
  Email triggers and draft creation

Teams
  Alerts and reminders

ServiceNow
  Ticket data source if ESP licensing permits it
```

## Main data objects

### Engineer Update Log

Used for field engineer updates, arrival, blockers, photos and completion status.

### Approval Evidence Log

Used to capture customer approvals, PO approvals, value approvals and billing validation.

### Escalation Log

Used for complaints, urgent issues, safety risks, blocked work and customer escalations.

### PO Burn Tracker

Used to track PO value, usage, remaining balance and risk level.

### Finance Risk Log

Used for project value, actuals, forecast costs, invoice status, PO status and margin risk.

### Attendance Evidence Log

Used to record early starts, installations, site visits, customer calls, travel and working context.

### Customer Update Draft Log

Used to track customer draft emails generated from engineer updates.

### Weekly Manager Update Log

Used to store weekly updates before sending to management.

## Flow pattern

Every automation should follow this pattern:

```text
Trigger
Condition
Action
Log
Notify
Save evidence
```

## Recommended permissions

Limit editing rights to project users only.

Give read-only access to senior stakeholders if needed.

Do not expose sensitive HR, legal or personal material in this work hub.
