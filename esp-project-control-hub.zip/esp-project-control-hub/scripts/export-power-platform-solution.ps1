param(
    [Parameter(Mandatory = $true)]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory = $true)]
    [string]$SolutionName,

    [Parameter(Mandatory = $false)]
    [string]$OutputFolder = ".\solution-export"
)

# Requires Microsoft Power Platform CLI:
# pac auth create --url https://YOURORG.crm.dynamics.com
# pac solution export --name SolutionName --path Solution.zip --managed false
# pac solution unpack --zipfile Solution.zip --folder OutputFolder

Write-Host "Authenticate first:"
Write-Host "pac auth create --url $EnvironmentUrl"

Write-Host "Export solution:"
Write-Host "pac solution export --name $SolutionName --path $SolutionName.zip --managed false"

Write-Host "Unpack solution:"
Write-Host "pac solution unpack --zipfile $SolutionName.zip --folder $OutputFolder"
