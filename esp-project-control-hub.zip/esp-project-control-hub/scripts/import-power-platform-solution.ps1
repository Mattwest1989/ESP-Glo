param(
    [Parameter(Mandatory = $true)]
    [string]$EnvironmentUrl,

    [Parameter(Mandatory = $true)]
    [string]$SolutionZip
)

# Requires Microsoft Power Platform CLI.
# This is a helper script for later once you have a real exported Power Platform solution zip.

Write-Host "Authenticate first:"
Write-Host "pac auth create --url $EnvironmentUrl"

Write-Host "Import solution:"
Write-Host "pac solution import --path $SolutionZip"
