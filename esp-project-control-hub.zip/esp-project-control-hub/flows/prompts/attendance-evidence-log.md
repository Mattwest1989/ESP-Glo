# Attendance Evidence Log

```text
Create a scheduled flow that runs every weekday at 06:30 and checks my Outlook calendar for events before 09:00. If an event contains install, survey, site, customer call or project meeting, create an item in the SharePoint list Attendance Evidence Log with date, event title, project, start time and reason. Then send me a Teams message asking me to confirm whether I am in the office, working from home, travelling, on a site visit or on an installation visit.
```
