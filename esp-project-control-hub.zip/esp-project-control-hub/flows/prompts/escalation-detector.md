# Escalation Detector

```text
Create an automated Outlook flow that checks new emails for escalation wording including escalation, complaint, legal, failed, unsafe, blocked, delayed, not acceptable, CEO, director, service failure or urgent. If detected, create an item in the SharePoint list Escalation Log with sender, subject, received date, project, risk level, action required and email link. Then send me a high-priority Teams message.
```
