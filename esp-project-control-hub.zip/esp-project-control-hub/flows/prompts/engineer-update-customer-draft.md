# Engineer Update Customer Draft

```text
Create a flow triggered when a new item is created in the SharePoint list Engineer Update Log. If Customer Update Needed equals Yes, create a draft Outlook email to the relevant customer contact. The draft should include site name, current status, progress completed, blockers, next steps and whether customer action is required. Do not send the email automatically. Add a row to Customer Update Draft Log and send me a Teams message.
```
