# Servicenow Ticket Tracker

```text
Create a scheduled Power Automate flow that runs every weekday at 08:30. It should get my ServiceNow records assigned to me or linked to Image Holders, Five Guys, Cleveron, Joe & The Juice or SITA. Add or update each record in a SharePoint list called ServiceNow Ticket Log. If the ticket has not been updated in 3 working days, send me a Teams message with the ticket number, project, status, last updated date and suggested follow-up action.
```
