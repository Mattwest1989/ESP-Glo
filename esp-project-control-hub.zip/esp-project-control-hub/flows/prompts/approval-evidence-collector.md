# Approval Evidence Collector

```text
Create an Outlook-triggered flow that monitors new emails for approval wording such as approved, agreed, confirmed, authorised, proceed, accepted, sign-off or validation. If the email also contains a PO number, invoice value, RITM, WOT or project name, save the email content into the Project Evidence Library in SharePoint and create a row in the Approval Evidence Log with date, sender, project, subject, approval wording and evidence link. Then send me a Teams message.
```
