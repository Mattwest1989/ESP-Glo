# Finance Variance Alert

```text
Create a scheduled flow that runs every weekday at 09:00 and checks the SharePoint list Finance Risk Log. If any item has a variance greater than 10%, missing PO status, missing invoice status, negative margin, or forecast cost at completion higher than project value, send me a Teams alert with the project name, issue, value, risk level and recommended next action.
```
