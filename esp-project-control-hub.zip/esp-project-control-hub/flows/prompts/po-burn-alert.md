# Po Burn Alert

```text
Create a scheduled flow that checks the SharePoint list PO Burn Tracker every weekday at 09:30. If any PO is more than 80% used, has missing approval evidence, has invoices not matched to approvals, or has a negative remaining balance, update the risk status to At Risk and send me a Teams alert with the customer, project, PO number, amount used, remaining balance and next action.
```
