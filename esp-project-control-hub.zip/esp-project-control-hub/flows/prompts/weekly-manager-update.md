# Weekly Manager Update

```text
Create a scheduled flow every Thursday at 08:30 that gathers open actions, completed actions, risks, blockers, ServiceNow updates, finance risks, PO risks and approval evidence from my SharePoint project lists. Format the output into a concise manager update with sections for Completed, In Progress, Risks, Support Required and Next Steps. Send it to me in Teams and create a draft Outlook email for review.
```
