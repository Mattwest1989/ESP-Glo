# Power Automate Flow Templates

These files are flow blueprints.

They are not guaranteed direct imports because real Power Automate exports contain tenant-specific connection references.

Use the files in `prompts/` with Power Automate Copilot.

Use the files in `templates/` as technical specs when building manually.
