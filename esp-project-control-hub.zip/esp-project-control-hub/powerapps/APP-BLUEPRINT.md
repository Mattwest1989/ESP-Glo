# Power Apps Blueprint

App name:

```text
ESP Project Control Hub
```

## Data sources

Add these SharePoint Lists as data sources:

```text
ServiceNow Ticket Log
Email Action Log
Approval Evidence Log
Engineer Update Log
Escalation Log
PO Burn Tracker
Finance Risk Log
Attendance Evidence Log
Customer Update Draft Log
Weekly Manager Update Log
Project Risk Register
```

## Screens

Create these screens:

```text
scrHome
scrEngineerUpdates
scrApprovalEvidence
scrEscalations
scrFinanceRisks
scrPOBurn
scrAttendanceEvidence
scrCustomerDrafts
scrWeeklyManagerUpdate
scrServiceNowTickets
scrRiskRegister
```

## Home dashboard layout

Top cards:

```text
Open Escalations
Approvals Awaiting Response
POs At Risk
Finance Risks
Engineer Updates Today
Tickets Needing Chase
```

Navigation buttons:

```text
Engineer Updates
Approval Evidence
Escalations
Finance Risks
PO Burn Tracker
Attendance Evidence
Customer Drafts
Weekly Update
ServiceNow Tickets
Risk Register
```

## Recommended app variables

Set these in `App.OnStart`:

```powerfx
Set(varUserEmail, User().Email);
Set(varToday, Today());
Set(varSelectedProject, Blank());
Set(varThemePrimary, RGBA(31, 78, 121, 1));
Set(varThemeAccent, RGBA(255, 184, 28, 1));
```

## Recommended first build

Build only these first:

```text
scrHome
scrEngineerUpdates
scrApprovalEvidence
scrEscalations
scrCustomerDrafts
```

Then add finance, PO, ServiceNow and attendance screens.
