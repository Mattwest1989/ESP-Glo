// Navigation component button formulas

// Home
Navigate(scrHome, ScreenTransition.Fade)

// Engineer Updates
Navigate(scrEngineerUpdates, ScreenTransition.Fade)

// Approval Evidence
Navigate(scrApprovalEvidence, ScreenTransition.Fade)

// Escalations
Navigate(scrEscalations, ScreenTransition.Fade)

// Finance Risks
Navigate(scrFinanceRisks, ScreenTransition.Fade)

// PO Burn
Navigate(scrPOBurn, ScreenTransition.Fade)

// Attendance Evidence
Navigate(scrAttendanceEvidence, ScreenTransition.Fade)

// Customer Drafts
Navigate(scrCustomerDrafts, ScreenTransition.Fade)

// Weekly Update
Navigate(scrWeeklyManagerUpdate, ScreenTransition.Fade)

// ServiceNow
Navigate(scrServiceNowTickets, ScreenTransition.Fade)

// Risk Register
Navigate(scrRiskRegister, ScreenTransition.Fade)
