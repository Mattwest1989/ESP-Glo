# scrAttendanceEvidence

Data source:

```text
Attendance Evidence Log
```

Purpose:

Record early starts, site visits, installation visits, customer calls, travel and working location context.

Gallery Items:

```powerfx
SortByColumns('Attendance Evidence Log', "EvidenceDate", Descending)
```

Save button:

```powerfx
SubmitForm(frmAttendanceEvidence)
```
