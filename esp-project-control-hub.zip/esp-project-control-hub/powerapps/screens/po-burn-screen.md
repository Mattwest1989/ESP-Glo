# scrPOBurn

Data source:

```text
PO Burn Tracker
```

At risk formula:

```powerfx
SortByColumns(
    Filter(
        'PO Burn Tracker',
        PercentageUsed >= 80
        || RiskStatus = "At Risk"
        || RemainingBalance < 0
        || ApprovalStatus = "Missing"
    ),
    "PercentageUsed",
    Descending
)
```
