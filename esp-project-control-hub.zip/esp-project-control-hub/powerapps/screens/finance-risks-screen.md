# scrFinanceRisks

Data source:

```text
Finance Risk Log
```

At risk gallery:

```powerfx
SortByColumns(
    Filter(
        'Finance Risk Log',
        RiskLevel = "High"
        || RiskLevel = "Critical"
        || POStatus = "Missing"
        || InvoiceStatus = "Missing"
        || ForecastCostAtCompletion > ProjectValue
    ),
    "RiskLevel",
    Descending
)
```
