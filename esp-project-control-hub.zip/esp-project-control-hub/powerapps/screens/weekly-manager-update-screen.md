# scrWeeklyManagerUpdate

Data source:

```text
Weekly Manager Update Log
```

Purpose:

Generate and store weekly manager update drafts.

Button formula:

```powerfx
Set(varWeeklyUpdateResult, GenerateWeeklyManagerUpdate.Run());
Notify("Weekly manager update draft requested.", NotificationType.Success)
```
