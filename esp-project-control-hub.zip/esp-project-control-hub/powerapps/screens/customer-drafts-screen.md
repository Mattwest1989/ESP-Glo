# scrCustomerDrafts

Data source:

```text
Customer Update Draft Log
```

Purpose:

Track customer drafts created by Power Automate.

Gallery Items:

```powerfx
SortByColumns('Customer Update Draft Log', "DraftDate", Descending)
```
