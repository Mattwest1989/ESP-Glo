# scrHome

Purpose:

The daily command centre.

Controls:

```text
Header label
Open escalations count card
Approvals awaiting response count card
POs at risk count card
Finance risks count card
Engineer updates today count card
Tickets needing chase count card
Navigation buttons
```

Gallery formulas:

```powerfx
Filter('Escalation Log', CurrentStatus <> "Closed")
Filter('Approval Evidence Log', ApprovalStatus = "Awaiting Customer Approval")
Filter('PO Burn Tracker', RiskStatus = "At Risk" || PercentageUsed >= 80)
Filter('Finance Risk Log', RiskLevel = "High" || RiskLevel = "Critical")
```
