# scrServiceNowTickets

Data source:

```text
ServiceNow Ticket Log
```

Tickets needing chase:

```powerfx
SortByColumns(
    Filter(
        'ServiceNow Ticket Log',
        NeedsChase = true
        || TicketStatus = "Blocked"
        || TicketStatus = "Awaiting Info"
    ),
    "LastUpdated",
    Ascending
)
```
