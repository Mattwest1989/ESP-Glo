# scrApprovalEvidence

Data source:

```text
Approval Evidence Log
```

Recommended controls:

```text
Gallery: galApprovals
Form: frmApprovalEvidence
Project filter
Approval status filter
Search box
```

Gallery Items:

```powerfx
SortByColumns(
    Filter(
        'Approval Evidence Log',
        IsBlank(txtApprovalSearch.Text)
        || StartsWith(Project.Value, txtApprovalSearch.Text)
        || StartsWith(Customer, txtApprovalSearch.Text)
        || StartsWith(PONumber, txtApprovalSearch.Text)
    ),
    "ApprovalDate",
    Descending
)
```

Save button:

```powerfx
SubmitForm(frmApprovalEvidence)
```
