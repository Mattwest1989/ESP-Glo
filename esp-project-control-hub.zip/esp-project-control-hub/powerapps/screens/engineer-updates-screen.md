# scrEngineerUpdates

Data source:

```text
Engineer Update Log
```

Recommended controls:

```text
Gallery: galEngineerUpdates
Form: frmEngineerUpdate
Button: Save Update
Button: Create Customer Draft
```

Save button:

```powerfx
SubmitForm(frmEngineerUpdate)
```

New button:

```powerfx
NewForm(frmEngineerUpdate)
```

Gallery Items:

```powerfx
SortByColumns('Engineer Update Log', "UpdateDate", Descending)
```
