# scrRiskRegister

Data source:

```text
Project Risk Register
```

Open risks:

```powerfx
SortByColumns(
    Filter(
        'Project Risk Register',
        Status <> "Closed"
    ),
    "DateRaised",
    Descending
)
```
