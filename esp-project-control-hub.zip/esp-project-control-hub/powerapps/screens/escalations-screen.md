# scrEscalations

Data source:

```text
Escalation Log
```

Gallery Items:

```powerfx
SortByColumns(
    Filter(
        'Escalation Log',
        CurrentStatus <> "Closed"
    ),
    "DateRaised",
    Descending
)
```

Critical filter:

```powerfx
Filter('Escalation Log', RiskLevel = "Critical" && CurrentStatus <> "Closed")
```

Save button:

```powerfx
SubmitForm(frmEscalation)
```
