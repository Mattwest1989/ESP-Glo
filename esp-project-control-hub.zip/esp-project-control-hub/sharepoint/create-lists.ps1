param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl
)

# Requires:
# Install-Module PnP.PowerShell -Scope CurrentUser

$ErrorActionPreference = "Stop"

$SchemaPath = Join-Path $PSScriptRoot "list-schemas.json"
$Schema = Get-Content $SchemaPath -Raw | ConvertFrom-Json

Connect-PnPOnline -Url $SiteUrl -Interactive

function Ensure-List {
    param(
        [string]$Title
    )

    $existing = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue

    if ($null -eq $existing) {
        Write-Host "Creating list: $Title"
        New-PnPList -Title $Title -Template GenericList -OnQuickLaunch | Out-Null
    }
    else {
        Write-Host "List already exists: $Title"
    }
}

function Field-Exists {
    param(
        [string]$ListTitle,
        [string]$InternalName
    )

    $field = Get-PnPField -List $ListTitle -Identity $InternalName -ErrorAction SilentlyContinue
    return $null -ne $field
}

function Add-TextField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type Text -AddToDefaultView | Out-Null
    }
}

function Add-NoteField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type Note -AddToDefaultView | Out-Null
    }
}

function Add-DateField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type DateTime -AddToDefaultView | Out-Null
    }
}

function Add-NumberField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type Number -AddToDefaultView | Out-Null
    }
}

function Add-CurrencyField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type Currency -AddToDefaultView | Out-Null
    }
}

function Add-BooleanField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type Boolean -AddToDefaultView | Out-Null
    }
}

function Add-UrlField {
    param($ListTitle, $InternalName, $DisplayName)
    if (-not (Field-Exists $ListTitle $InternalName)) {
        Add-PnPField -List $ListTitle -DisplayName $DisplayName -InternalName $InternalName -Type URL -AddToDefaultView | Out-Null
    }
}

function Add-ChoiceField {
    param($ListTitle, $InternalName, $DisplayName, $Choices)

    if (-not (Field-Exists $ListTitle $InternalName)) {
        $choiceXml = ""
        foreach ($choice in $Choices) {
            $choiceXml += "<CHOICE>$choice</CHOICE>"
        }

        $fieldXml = @"
<Field Type="Choice" DisplayName="$DisplayName" StaticName="$InternalName" Name="$InternalName" Format="Dropdown">
  <CHOICES>
    $choiceXml
  </CHOICES>
</Field>
"@

        Add-PnPFieldFromXml -List $ListTitle -FieldXml $fieldXml | Out-Null
        Add-PnPField -List $ListTitle -Identity $InternalName -AddToDefaultView -ErrorAction SilentlyContinue | Out-Null
    }
}

foreach ($list in $Schema.lists) {
    Ensure-List -Title $list.title

    foreach ($column in $list.columns) {
        Write-Host "Ensuring column $($column.displayName) on $($list.title)"

        switch ($column.type) {
            "Text" { Add-TextField $list.title $column.name $column.displayName }
            "Note" { Add-NoteField $list.title $column.name $column.displayName }
            "DateTime" { Add-DateField $list.title $column.name $column.displayName }
            "Number" { Add-NumberField $list.title $column.name $column.displayName }
            "Currency" { Add-CurrencyField $list.title $column.name $column.displayName }
            "Boolean" { Add-BooleanField $list.title $column.name $column.displayName }
            "URL" { Add-UrlField $list.title $column.name $column.displayName }
            "Choice" { Add-ChoiceField $list.title $column.name $column.displayName $column.choices }
            default { Write-Warning "Unsupported field type: $($column.type)" }
        }
    }
}

Write-Host "Done. SharePoint lists are ready."
